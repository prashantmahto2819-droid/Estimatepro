// Supabase project: estimate-pro (Mumbai, ap-south-1)
// The publishable key is public by design: the database rules (RLS) decide what each user can do.
window.EP_CONFIG = {
  url: "https://pjwjntdldtrpbhdocrda.supabase.co",
  anonKey: "sb_publishable_b7GQyNlhjKhV1wikMzgsSQ_025t6O89"
};
