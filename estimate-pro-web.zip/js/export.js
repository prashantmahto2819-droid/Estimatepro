/* Estimate Pro — Excel export: Measurement, Analysis, Abstract (per part), General Abstract, BOQ */
(function () {
  "use strict";
  var EP = window.EP, X = null, T;
  function H(len, width) { var per = Math.max(10, Math.floor(width * 1.15)); return Math.max(14, Math.ceil((len || 1) / per) * 12.5 + 2); }
  function q(name) { return "'" + name.replace(/'/g, "''") + "'"; }

  function header(ws, r, n, doc, title, part) {
    var h = doc.header || {};
    [[h.org, X.S.title, 18], [h.office, X.S.subtitle, 15], [h.project, X.S.subtitle, 15]].forEach(function (x) {
      if (!x[0]) return; ws.set(r, 0, x[0], x[1]); ws.merge(r, 0, r, n - 1); ws.height(r, x[2]); r++;
    });
    if (h.work) { var t = "Name of work: " + h.work; ws.set(r, 0, t, X.S.bold); ws.merge(r, 0, r, n - 1); ws.height(r, H(t.length, n * 11)); r++; }
    ws.set(r, 0, title, X.S.title); ws.merge(r, 0, r, n - 1); ws.height(r, 17); r++;
    if (part) { ws.set(r, 0, part, X.S.subtitle); ws.merge(r, 0, r, n - 1); r++; }
    return r;
  }
  function footer(ws, r, n, doc) {
    r += 2; var s = (doc.signs || []).filter(function (x) { return x.title || x.place; }); if (!s.length) return r;
    var pos = s.length === 1 ? [n - 2] : s.length === 2 ? [1, n - 2] : [1, Math.floor((n - 1) / 2), n - 2];
    s.slice(0, 3).forEach(function (x, i) { var c = pos[i]; ws.set(r, c, x.title, X.S.signb); if (x.place) ws.set(r + 1, c, x.place, X.S.sign); });
    return r + 2;
  }
  function heads(ws, r, labels) { labels.forEach(function (l, c) { ws.set(r, c, l, X.S.head); }); ws.height(r, 28); return r + 1; }
  function box(ws, r, n, skip) { for (var c = 0; c < n; c++) if (!skip || skip.indexOf(c) < 0) { var row = ws.rows[r]; if (!row || !row[c]) ws.set(r, c, "", X.S.text); } }
  function partTitle(doc, p) { return doc.parts.length > 1 ? p.name : ""; }
  function itemsOf(doc, p) { return EP.partItems(doc, p.id); }
  function anKey(it) { return it.b === "x" ? "x|" + it.id : it.b + "|" + it.c + "|" + (EP.ev(it.anr) == null ? "" : EP.ev(it.anr)); }

  /* ---------- Measurement ---------- */
  function measurement(wb, doc, ctx) {
    var n = 10, ws = wb.sheet("Measurement", { cols: [6, 44, 7, 7, 8, 8, 8, 9, 12, 20] }), r = 0;
    doc.parts.forEach(function (p, pi) {
      if (pi) ws.pageBreak(r);
      r = header(ws, r, n, doc, "MEASUREMENT", partTitle(doc, p));
      r = heads(ws, r, ["Sl. No.", "Item / Details", "Unit", "No.", "L (m)", "B (m)", "D / H (m)", "Factor", "Qty", "Remarks"]);
      itemsOf(doc, p).forEach(function (it, ii) {
        var inf = EP.itemInfo(it);
        ws.set(r, 0, ii + 1, X.S.center); ws.set(r, 1, inf.desc, X.S.btext); ws.set(r, 2, inf.unit, X.S.center); ws.set(r, 9, inf.src, X.S.text);
        box(ws, r, n); ws.height(r, H(inf.desc.length, 44)); r++;
        var plus = [], minus = [], rows = it.meas || [];
        rows.forEach(function (m) {
          if (m.k === "h") { ws.set(r, 1, m.d || "", X.S.itext); box(ws, r, n); r++; return; }
          var val = EP.rowQty(doc, m) || 0, cell;
          if (m.k === "ref") {
            var t = doc.items.filter(function (i) { return i.id === m.ref; })[0], tq = t && ctx.qtyRow[t.id];
            var mult = EP.ev(m.n);
            ws.set(r, 1, (m.d ? m.d + " — " : "") + (t ? "Same as item " + EP.slOf(doc, t) + (doc.parts.length > 1 ? " of " + (doc.parts.filter(function (x) { return x.id === t.part; })[0] || {}).name : "") : "Same as another item"), X.S.text);
            var md = m.m === "pct" ? " × " + (mult || 0) + "% × 7850 kg/cum" : m.m === "kgcum" ? " @ " + (mult || 0) + " kg/cum" : (mult != null ? " × " + mult : "");
            ws.rows[r][1].v += " (" + EP.r3(t ? EP.itemQty(doc, t) : 0) + " " + (t ? EP.itemInfo(t).unit : "") + ")" + md;
            if (mult != null) ws.set(r, 3, mult, X.S.dim);
            ws.set(r, 2, inf.unit, X.S.center);
            cell = ws.set(r, 8, val, X.S.qty, tq != null ? "I" + (tq + 1) + (mult != null ? "*D" + (r + 1) + (m.m === "pct" ? "/100*7850" : "") : "") : null);
          } else {
            var st = m.sec ? EP.steel(m.sec) : null;
            ws.set(r, 1, (m.k === "-" ? "Deduct: " : "") + (m.d || "") + (m.sec ? (m.d ? " — " : "") + m.sec + " @ " + EP.ev(m.f) + (/plate/i.test(m.sec) ? " kg/sqm" : " kg/m") + (st ? " (" + st[2] + ")" : "") : ""), m.k === "-" ? X.S.itext : X.S.text);
            ws.set(r, 2, inf.unit, X.S.center);
            var f = [];
            [["n", 3], ["l", 4], ["b", 5], ["h", 6], ["f", 7]].forEach(function (k) { var v = EP.ev(m[k[0]]); if (v != null) { ws.set(r, k[1], v, X.S.dim); f.push(X.col(k[1]) + (r + 1)); } });
            var manual = EP.ev(m.q);
            cell = ws.set(r, 8, val, X.S.qty, manual == null && f.length ? f.join("*") : null);
          }
          box(ws, r, n); (m.k === "-" ? minus : plus).push("I" + (r + 1)); r++;
        });
        var qty = EP.itemQty(doc, it);
        if (!plus.length && !minus.length) { ws.set(r, 1, "Quantity", X.S.btext); ws.set(r, 2, inf.unit, X.S.center); ws.set(r, 8, qty, X.S.bqty); box(ws, r, n); ctx.qtyRow[it.id] = r; r++; }
        else if (minus.length) {
          var g = r; ws.set(r, 1, "Gross total", X.S.btext); ws.set(r, 2, inf.unit, X.S.center); ws.set(r, 8, EP.measSum(doc, it).plus, X.S.bqty, plus.length ? plus.join("+") : null); box(ws, r, n); r++;
          var d = r; ws.set(r, 1, "Less: deductions", X.S.btext); ws.set(r, 2, inf.unit, X.S.center); ws.set(r, 8, EP.measSum(doc, it).minus, X.S.bqty, minus.join("+")); box(ws, r, n); r++;
          ws.set(r, 1, "Net total", X.S.btext); ws.set(r, 2, inf.unit, X.S.center); ws.set(r, 8, qty, X.S.bqty, "I" + (g + 1) + "-I" + (d + 1)); box(ws, r, n); ctx.qtyRow[it.id] = r; r++;
        } else { ws.set(r, 1, "Total", X.S.btext); ws.set(r, 2, inf.unit, X.S.center); ws.set(r, 8, qty, X.S.bqty, plus.length > 1 ? plus.join("+") : plus[0]); box(ws, r, n); ctx.qtyRow[it.id] = r; r++; }
      });
      r++;
    });
    footer(ws, r, n, doc);
  }

  /* ---------- Analysis ---------- */
  function analysis(wb, doc, ctx) {
    var n = 7, ws = wb.sheet("Analysis", { cols: [10, 50, 11, 6, 8, 10, 13] }), r = 0, done = {}, k = 0;
    r = header(ws, r, n, doc, "ANALYSIS OF RATES (UPDATED)", "");
    doc.parts.forEach(function (p) {
      itemsOf(doc, p).forEach(function (it) {
        var key = anKey(it); if (done[key]) return; done[key] = 1; k++;
        var inf = EP.itemInfo(it), lr = EP.lineRates(doc, it), start = r;
        r++;
        ws.set(r, 0, k + ". " + (inf.code || ""), X.S.bold); ws.set(r, 1, inf.desc, X.S.bold); ws.merge(r, 1, r, n - 1); ws.height(r, H(inf.desc.length, 90)); r++;
        ws.set(r, 1, inf.src + (doc.parts.length > 1 ? " — used in " + doc.parts.map(function (pp) { var sl = itemsOf(doc, pp).map(function (x, i) { return anKey(x) === key ? i + 1 : 0; }).filter(Boolean); return sl.length ? pp.name + " item " + sl.join(", ") : ""; }).filter(Boolean).join("; ") : ""), X.S.note); ws.merge(r, 1, r, n - 1); r++;
        var o = it.b !== "x" ? EP.itemOvr(it.b, it.c) : null;
        var useBuild = EP.hasAn(it.b, it.c) && lr.how !== "SOR rate" && !(o && o.mode === "manual") && EP.ev(it.anr) == null;
        if (EP.hasAn(it.b, it.c)) {
          var bu = EP.build(it.c, o && o.mode === "build" ? o : null);
          ws.set(r, 1, "Details of cost for " + bu.basis + " " + inf.unit, X.S.itext); r++;
          r = heads(ws, r, ["Code", "Description", "Rate (₹)", "Per", "Unit", "Qty", "Amount (₹)"]);
          var first = r, sec = null;
          bu.lines.forEach(function (l) {
            if (l.sec && l.sec !== sec) { sec = l.sec; ws.set(r, 1, { M: "MATERIAL", L: "LABOUR", C: "CARRIAGE" }[sec] || sec, X.S.btext); box(ws, r, n); r++; }
            ws.set(r, 0, l.code || "", X.S.center); ws.set(r, 1, l.desc || "", X.S.text);
            if (l.r != null) ws.set(r, 2, EP.r2(l.r), X.S.num);
            if (l.per && l.per !== 1) ws.set(r, 3, l.per, X.S.center);
            ws.set(r, 4, l.unit || "", X.S.center);
            if (l.q != null) ws.set(r, 5, l.q, X.S.qty);
            ws.set(r, 6, EP.r2(l.amt), X.S.num, l.r != null && l.q != null ? "C" + (r + 1) + "*F" + (r + 1) + (l.per && l.per !== 1 ? "/D" + (r + 1) : "") : null);
            box(ws, r, n); ws.height(r, H((l.desc || "").length, 50)); r++;
          });
          var tot = r; ws.set(r, 1, "TOTAL", X.S.btext); ws.set(r, 6, EP.r2(bu.sub), X.S.bnum, "SUM(G" + (first + 1) + ":G" + r + ")"); box(ws, r, n); r++;
          bu.adds.forEach(function (a, j) {
            ws.set(r, 1, "Add " + a.pct + "% " + (a.label || "").replace(/^\s*\d+(\.\d+)?\s*%\s*/, "") + (a.except ? " (on part of cost)" : ""), X.S.text);
            ws.set(r, 6, EP.r2(a.amt), X.S.num, a.except ? null : "G" + (tot + 1) + "*" + a.pct + "/100"); box(ws, r, n); var add = r; r++;
            ws.set(r, 1, j === bu.adds.length - 1 ? "Cost for " + bu.basis + " " + inf.unit : "TOTAL", X.S.btext); ws.set(r, 6, EP.r2(a.run), X.S.bnum, "G" + (tot + 1) + "+G" + (add + 1)); box(ws, r, n); tot = r; r++;
          });
          if (bu.basis && bu.basis !== 1) { ws.set(r, 1, "Cost for 1 " + inf.unit, X.S.btext); ws.set(r, 6, EP.r2(bu.total / bu.basis), X.S.bnum, "G" + (tot + 1) + "/" + bu.basis); box(ws, r, n); r++; }
          if (Math.abs(bu.total / bu.basis - bu.rate) > 0.5) { ws.set(r, 1, "Scaled to the book's build-up (₹" + EP.r2(bu.anchor) + ") × change in cost", X.S.note); ws.merge(r, 1, r, n - 1); r++; }
          if (!useBuild) {
            ws.set(r, 1, "Updated rate adopted: " + lr.how + (o && o.why ? " — " + o.why : ""), X.S.btext); ws.set(r, 6, lr.a, X.S.bnum); box(ws, r, n); ctx.anRow[key] = r; r++;
          } else { ws.set(r, 1, "Say (updated rate)", X.S.btext); ws.set(r, 6, lr.a, X.S.bnum); box(ws, r, n); ctx.anRow[key] = r; r++; }
        } else {
          r = heads(ws, r, ["", "Basis of rate", "", "", "Unit", "", "Rate (₹)"]);
          var bk = EP.BOOKS[it.b];
          ws.set(r, 1, it.b === "x" ? "Estimate rate — " + inf.src : "Rate as per " + (bk ? bk.long : "") + ", item " + it.c, X.S.text); ws.set(r, 4, inf.unit, X.S.center); ws.set(r, 6, lr.s, X.S.num); box(ws, r, n); r++;
          var why = it.b === "x" ? (it.x && it.x.why) : (o && o.why) || (EP.item(it.b, it.c) || {}).anNote;
          ws.set(r, 1, "Updated rate — " + lr.how + (why ? ": " + why : ""), X.S.btext); ws.set(r, 4, inf.unit, X.S.center); ws.set(r, 6, lr.a, X.S.bnum); box(ws, r, n); ctx.anRow[key] = r; r++;
        }
        if (start === 0) {}
      });
    });
    footer(ws, r + 1, n, doc);
  }

  /* ---------- Abstract (one block per part) ---------- */
  function abstract(wb, doc, ctx, linked) {
    var n = 9, ws = wb.sheet("Abstract", { cols: [6, 46, 7, 11, 11, 14, 11, 14, 20] }), r = 0, g = (+doc.gst || 0);
    doc.parts.forEach(function (p, pi) {
      if (pi) ws.pageBreak(r);
      r = header(ws, r, n, doc, "ABSTRACT OF COST", partTitle(doc, p));
      ["Sl. No.", "Description", "Unit", "Qty", "Estimate (SOR)", "", "Updated cost", "", "Remarks"].forEach(function (l, c) { ws.set(r, c, l, X.S.head); ws.set(r + 1, c, "", X.S.head); });
      ws.set(r + 1, 4, "Rate (₹)", X.S.head); ws.set(r + 1, 5, "Amount (₹)", X.S.head); ws.set(r + 1, 6, "Rate (₹)", X.S.head); ws.set(r + 1, 7, "Amount (₹)", X.S.head);
      [0, 1, 2, 3, 8].forEach(function (c) { ws.merge(r, c, r + 1, c); }); ws.merge(r, 4, r, 5); ws.merge(r, 6, r, 7); r += 2;
      var first = r;
      itemsOf(doc, p).forEach(function (it, ii) {
        var inf = EP.itemInfo(it), lr = EP.lineRates(doc, it), R = r + 1;
        ws.set(r, 0, ii + 1, X.S.center); ws.set(r, 1, inf.desc, X.S.text); ws.set(r, 2, inf.unit, X.S.center);
        ws.set(r, 3, lr.q, X.S.qty, linked && ctx.qtyRow[it.id] != null ? "Measurement!I" + (ctx.qtyRow[it.id] + 1) : null);
        ws.set(r, 4, lr.s, X.S.num); ws.set(r, 5, lr.sa, X.S.num, "D" + R + "*E" + R);
        ws.set(r, 6, lr.a, X.S.num, linked && ctx.anRow[anKey(it)] != null ? "Analysis!G" + (ctx.anRow[anKey(it)] + 1) : null);
        ws.set(r, 7, lr.aa, X.S.num, "D" + R + "*G" + R);
        ws.set(r, 8, inf.src + (it.rem ? " — " + it.rem : ""), X.S.text);
        ws.height(r, H(inf.desc.length, 46)); r++;
      });
      var t = EP.totals(doc).parts[pi], last = r;
      ws.set(r, 1, "TOTAL", X.S.btext); ws.set(r, 4, "Rs.", X.S.btext); ws.set(r, 5, t.s, X.S.bnum, last > first ? "SUM(F" + (first + 1) + ":F" + last + ")" : null); ws.set(r, 6, "Rs.", X.S.btext); ws.set(r, 7, t.a, X.S.bnum, last > first ? "SUM(H" + (first + 1) + ":H" + last + ")" : null); box(ws, r, n);
      ctx.partTot[p.id] = r; var tr = r + 1; r++;
      ws.set(r, 1, "Add GST @ " + g + "%", X.S.text); ws.set(r, 5, EP.r2(t.s * g / 100), X.S.num, "F" + tr + "*" + g + "/100"); ws.set(r, 7, EP.r2(t.a * g / 100), X.S.num, "H" + tr + "*" + g + "/100"); box(ws, r, n); r++;
      ws.set(r, 1, "Grand total", X.S.btext); ws.set(r, 5, EP.r2(t.s * (1 + g / 100)), X.S.bnum, "F" + tr + "+F" + (tr + 1)); ws.set(r, 7, EP.r2(t.a * (1 + g / 100)), X.S.bnum, "H" + tr + "+H" + (tr + 1)); box(ws, r, n); r++;
      r = footer(ws, r, n, doc) + 1;
    });
  }

  /* ---------- General abstract ---------- */
  function general(wb, doc, ctx, linked) {
    var n = 5, ws = wb.sheet("General Abstract", { cols: [7, 42, 18, 18, 22] }), r = 0, T = EP.totals(doc), g = (+doc.gst || 0);
    r = header(ws, r, n, doc, "GENERAL ABSTRACT OF COST", "");
    r = heads(ws, r, ["Sl. No.", "Description", "Estimate cost (SOR) ₹", "Updated cost ₹", "Remarks"]);
    var first = r;
    T.parts.forEach(function (p, i) {
      var tr = ctx.partTot[p.id];
      ws.set(r, 0, i + 1, X.S.center); ws.set(r, 1, p.name, X.S.text);
      ws.set(r, 2, p.s, X.S.num, linked && tr != null ? "Abstract!F" + (tr + 1) : null); ws.set(r, 3, p.a, X.S.num, linked && tr != null ? "Abstract!H" + (tr + 1) : null); ws.set(r, 4, "", X.S.text); r++;
    });
    var tr2 = r + 1;
    ws.set(r, 1, "TOTAL", X.S.btext); ws.set(r, 2, T.s, X.S.bnum, "SUM(C" + (first + 1) + ":C" + r + ")"); ws.set(r, 3, T.a, X.S.bnum, "SUM(D" + (first + 1) + ":D" + r + ")"); box(ws, r, n); r++;
    ws.set(r, 1, "Add GST @ " + g + "%", X.S.text); ws.set(r, 2, T.sg, X.S.num, "C" + tr2 + "*" + g + "/100"); ws.set(r, 3, T.ag, X.S.num, "D" + tr2 + "*" + g + "/100"); box(ws, r, n); r++;
    ws.set(r, 1, "Grand total", X.S.btext); ws.set(r, 2, T.sT, X.S.bnum, "C" + tr2 + "+C" + (tr2 + 1)); ws.set(r, 3, T.aT, X.S.bnum, "D" + tr2 + "+D" + (tr2 + 1)); box(ws, r, n); r++;
    ws.set(r, 1, "Say (₹ in lakh)", X.S.text); ws.set(r, 2, EP.r2(T.sT / 1e5), X.S.num, "ROUND(C" + (tr2 + 2) + "/100000,2)"); ws.set(r, 3, EP.r2(T.aT / 1e5), X.S.num, "ROUND(D" + (tr2 + 2) + "/100000,2)"); box(ws, r, n); r++;
    footer(ws, r, n, doc);
  }

  /* ---------- BOQ (for tender; rates left blank for bidders) ---------- */
  function boq(wb, doc, ctx, linked) {
    var n = 7, ws = wb.sheet("BOQ", { cols: [6, 50, 8, 11, 12, 24, 15] }), r = 0;
    doc.parts.forEach(function (p, pi) {
      if (pi) ws.pageBreak(r);
      r = header(ws, r, n, doc, "BILL OF QUANTITIES", partTitle(doc, p));
      r = heads(ws, r, ["Sl. No.", "Description of item", "Unit", "Quantity", "Rate (₹) in figures", "Rate in words", "Amount (₹)"]);
      var first = r;
      itemsOf(doc, p).forEach(function (it, ii) {
        var inf = EP.itemInfo(it), R = r + 1;
        ws.set(r, 0, ii + 1, X.S.center); ws.set(r, 1, inf.desc, X.S.text); ws.set(r, 2, inf.unit, X.S.center);
        ws.set(r, 3, EP.itemQty(doc, it), X.S.qty, linked && ctx.qtyRow[it.id] != null ? "Measurement!I" + (ctx.qtyRow[it.id] + 1) : null);
        ws.set(r, 4, "", X.S.num); ws.set(r, 5, "", X.S.text); ws.set(r, 6, 0, X.S.num, "IF(E" + R + "=\"\",0,D" + R + "*E" + R + ")");
        ws.height(r, H(inf.desc.length, 50)); r++;
      });
      ws.set(r, 1, "Total", X.S.btext); ws.set(r, 6, 0, X.S.bnum, r > first ? "SUM(G" + (first + 1) + ":G" + r + ")" : null); box(ws, r, n); r++;
      r = footer(ws, r, n, doc) + 1;
    });
  }

  /* which: all | meas | an | abs | gen | boq */
  EP.buildWorkbook = function (doc, which) {
    X = window.XW; var wb = X.book(), ctx = { qtyRow: {}, anRow: {}, partTot: {} }, all = which === "all";
    // Build hidden-order: Measurement and Analysis first so the abstract can link to them.
    if (all) { measurement(wb, doc, ctx); analysis(wb, doc, ctx); abstract(wb, doc, ctx, true); general(wb, doc, ctx, true); boq(wb, doc, ctx, true); }
    else if (which === "meas") measurement(wb, doc, ctx);
    else if (which === "an") analysis(wb, doc, ctx);
    else if (which === "abs") abstract(wb, doc, ctx, false);
    else if (which === "gen") general(wb, doc, ctx, false);
    else if (which === "boq") boq(wb, doc, ctx, false);
    return wb.blob();
  };
  EP.download = function (blob, filename) {
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = filename;
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  };
})();
