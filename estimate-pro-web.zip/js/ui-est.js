/* Estimate Pro — estimates: projects, parts, items, measurement sheets, header, abstract preview, export */
(function () {
  "use strict";
  var EP = window.EP, S = EP.S, U = EP.ui, esc = U.esc, inr = U.inr;
  function db() { return U.db(); }
  function doc() { return S.est.cur ? S.est.cur.doc : null; }
  function ro() { return !S.est.cur || (S.est.owner !== S.me.id && !S.me.isOwner); }
  function findItem(id) { var d = doc(); return d ? d.items.filter(function (i) { return i.id === id; })[0] : null; }
  function curPart() { var d = doc(); if (!d) return null; if (!d.parts.some(function (p) { return p.id === S.est.part; })) S.est.part = d.parts[0].id; return S.est.part; }

  /* ---------- loading & saving ---------- */
  function rowToEst(x) { return { id: x.id, owner: x.owner, name: x.name, created: Date.parse(x.created_at), updated: Date.parse(x.updated_at), doc: EP.migrate(x) }; }
  var estReq = 0;
  U.watchEst = async function (owner, keepSel) {
    var changed = owner !== S.est.lastOwner;
    S.est.owner = owner; if (changed && !keepSel) S.est.selId = null; S.est.lastOwner = owner;
    var my = ++estReq;
    var r = await db().from("estimates").select("*").eq("owner", owner).order("created_at", { ascending: false });
    if (my !== estReq) return; if (U.fail(r, "Couldn't load estimates. Reload to try again.")) return;
    S.est.list = r.data.map(rowToEst);
    if (owner === S.me.id) S.est.mine = S.est.list;
    if (!S.est.list.some(function (x) { return x.id === S.est.selId; })) S.est.selId = S.est.list.length ? S.est.list[0].id : null;
    pick(); U.render();
    if (owner === S.me.id && S.me.isOwner) U.loadUsers();
  };
  function pick() { var f = S.est.list.filter(function (x) { return x.id === S.est.selId; })[0]; S.est.cur = f || null; S.est.part = f ? f.doc.parts[0].id : null; S.est.open = {}; }
  var saveT = 0;
  function save(now) {
    var e = S.est.cur; if (!e || ro()) return; clearTimeout(saveT);
    saveT = setTimeout(async function () {
      saveT = 0; var d = e.doc;
      var r = await db().from("estimates").update({ name: e.name || "Untitled estimate", gst: +d.gst || 0, data: d }).eq("id", e.id);
      if (U.fail(r, "Couldn't save. Check your connection.")) return;
      e.updated = Date.now(); var st = document.getElementById("save-state"); if (st) st.textContent = "Saved";
    }, now ? 0 : 600);
    var st = document.getElementById("save-state"); if (st) st.textContent = "Saving…";
  }
  function change(fn, rerender) { if (ro()) return; fn(doc()); save(); if (rerender !== false) U.render(); }
  async function newEstimate(name, d) {
    var r = await db().from("estimates").insert({ name: name, gst: d.gst, data: d, owner: S.me.id }).select("id").single();
    if (U.fail(r, "Couldn't create the estimate.")) return;
    S.est.selId = r.data.id; S.est.lastOwner = S.me.id; S.est.sub = "items"; await U.watchEst(S.me.id, true); U.toast("Created " + name);
  }
  function defaults() { var d = S.me.defaults || {}; return { header: d.header, signs: d.signs, gst: d.gst }; }

  /* ---------- views ---------- */
  U.views.estimates = function () {
    var h = '<div class="est-grid"><aside class="panel" style="padding:14px;display:flex;flex-direction:column;gap:12px">';
    if (S.me.isOwner && S.est.users.length > 1) h += '<label class="lbl" for="est-owner">Viewing projects of</label><select id="est-owner" class="in">' + S.est.users.map(function (u) { return '<option value="' + esc(u) + '"' + (u === S.est.owner ? " selected" : "") + ">" + esc(u === S.me.id ? "Me (" + (S.me.name || "you") + ")" : U.nameOf(u)) + "</option>"; }).join("") + "</select>";
    h += '<h2>Projects</h2><form id="new-est" class="row" style="gap:8px"><input id="new-name" class="in grow" placeholder="New estimate name" aria-label="New estimate name" required><button class="btn pri sm" type="submit">Create</button></form><div class="list-est">';
    if (!S.est.list.length) h += '<div class="muted" style="padding:8px 2px">No estimates yet.</div>' + (S.est.owner === S.me.id ? '<button type="button" class="btn sec" id="mk-example">Create example: weigh-bridge (Part A + Part B)</button>' : "");
    S.est.list.forEach(function (e) {
      var T = EP.totals(e.doc);
      h += '<button type="button" data-est="' + esc(e.id) + '" aria-current="' + (e.id === S.est.selId) + '"><strong>' + esc(e.name) + '</strong><span class="muted" style="font-size:12px">' + e.doc.items.length + " items · " + e.doc.parts.length + " part" + (e.doc.parts.length > 1 ? "s" : "") + " · ₹" + inr(T.aT, 0) + "</span></button>";
    });
    h += "</div></aside><section class='ed'>";
    var e = S.est.cur;
    if (!e) return h + '<div class="panel empty">Create an estimate or pick one on the left.</div></section></div>';
    var d = e.doc, T = EP.totals(d), sub = S.est.sub;
    h += '<div class="row ed-top"><div class="grow" style="min-width:0"><div class="lbl">' + (S.est.owner === S.me.id ? "My project" : "Project of " + esc(U.nameOf(S.est.owner))) + ' · <span id="save-state">' + (ro() ? "Read-only" : "Saved") + '</span></div><input id="est-name" class="in title-in" value="' + esc(e.name) + '" aria-label="Estimate name"' + (ro() ? " disabled" : "") + "></div>" + (ro() ? "" : '<button class="btn ghost sm" id="del-est" type="button">Delete estimate</button>') + "</div>";
    h += '<div class="stats"><div class="stat"><div class="lbl">Estimate cost (SOR)</div><div class="v">₹' + inr(T.s) + '</div></div><div class="stat"><div class="lbl">Updated cost</div><div class="v">₹' + inr(T.a) + '</div></div><div class="stat"><div class="lbl">GST ' + esc(d.gst) + '%</div><div class="v">₹' + inr(T.ag) + '</div></div><div class="stat"><div class="lbl">Grand total (updated)</div><div class="v">₹' + inr(T.aT) + "</div></div></div>";
    h += '<div class="seg subtabs" role="group" aria-label="Estimate sections">' + [["items", "Items & measurement"], ["header", "Header, parts & GST"], ["abstract", "Abstract"], ["export", "Export to Excel"]].map(function (s) { return '<button type="button" data-sub="' + s[0] + '" aria-pressed="' + (sub === s[0]) + '">' + s[1] + "</button>"; }).join("") + "</div>";
    if (sub === "header") h += viewHeader(d); else if (sub === "abstract") h += viewAbstract(d); else if (sub === "export") h += viewExport(d); else h += viewItems(d);
    return h + "</section></div>";
  };

  /* ----- items & measurement ----- */
  var TYPES = [["+", "Add"], ["-", "Deduct"], ["h", "Heading"], ["ref", "From item"]];
  function viewItems(d) {
    var pid = curPart(), R = ro();
    var h = '<div class="row" style="gap:8px;flex-wrap:wrap"><div class="seg" role="group" aria-label="Parts">' + d.parts.map(function (p) { var n = EP.partItems(d, p.id).length; return '<button type="button" data-part="' + esc(p.id) + '" aria-pressed="' + (p.id === pid) + '">' + esc(p.name) + ' <span class="cnt">(' + n + ")</span></button>"; }).join("") + "</div>" + (R ? "" : '<button type="button" class="btn ghost sm" id="add-part">+ Add part</button>') + "</div>";
    if (!R) h += '<div class="row add-row"><div class="grow" style="position:relative"><input id="add-q" class="in" style="width:100%" placeholder="Add item to ' + esc(partName(d, pid)) + ': type a code (6.34.2, 3.3, 2.35) or words (vitrified tiles, doob grass)" aria-label="Search items to add" autocomplete="off" value="' + esc(S.est.addQ) + '">' + addDropdown() + '</div><button type="button" class="btn sec" id="add-x">+ Non-SOR item</button></div>';
    var items = EP.partItems(d, pid);
    h += '<div class="tw"><table class="t est"><thead><tr><th class="num">Sl</th><th>SOR & item</th><th>Description</th><th>Unit</th><th class="num">Qty</th><th class="num">SOR rate ₹</th><th class="num">SOR amount ₹</th><th class="num">Updated rate ₹</th><th class="num">Updated amount ₹</th><th></th></tr></thead><tbody>';
    var ts = 0, ta = 0;
    items.forEach(function (it, i) {
      var inf = EP.itemInfo(it), r = EP.lineRates(d, it), m = EP.measSum(d, it), open = !!S.est.open[it.id];
      ts += r.sa; ta += r.aa;
      var qcell = m.n ? '<span class="qv">' + U.qfmt(r.q) + "</span>" : "<input class='in small n' id='iq-" + it.id + "' data-iq='" + it.id + "' value='" + esc(it.q || "") + "' inputmode='decimal' aria-label='Quantity'" + (R ? " disabled" : "") + ">";
      h += "<tr class='irow" + (open ? " open" : "") + "'><td class='num'>" + (i + 1) + "</td><td style='white-space:nowrap'><span class='sw " + (it.b.indexOf("u:") === 0 ? "u" : it.b) + "'></span>" + esc(it.b === "x" ? "Non-SOR" : (EP.BOOKS[it.b] || {}).name || "SOR") + "<br><strong>" + esc(inf.code) + "</strong></td><td><div class='desc' title='" + esc(inf.desc) + "'>" + esc(inf.desc) + "</div>" + (inf.missing ? "<span class='badge warn'>Not in SOR</span>" : "") + "</td><td>" + esc(inf.unit) + "</td><td class='num'>" + qcell + "</td><td class='num'>" + inr(r.s) + "</td><td class='num'>" + inr(r.sa) + "</td><td class='num'>" + inr(r.a) + (Math.abs((r.a || 0) - (r.s || 0)) > 0.004 ? "<br><span class='badge ed'>" + esc(r.how) + "</span>" : "") + "</td><td class='num'>" + inr(r.aa) + "</td>" +
        "<td class='acts'><button class='btn " + (open ? "pri" : "sec") + " sm' data-open='" + it.id + "' aria-expanded='" + open + "'>" + (open ? "Close" : "Measure" + (m.n ? " (" + m.n + ")" : "")) + "</button>" + (R ? "" : "<button class='btn ghost sm' data-mv='" + it.id + "|-1' aria-label='Move up'>↑</button><button class='btn ghost sm' data-mv='" + it.id + "|1' aria-label='Move down'>↓</button><button class='btn ghost sm' data-del='" + it.id + "' aria-label='Remove item'>✕</button>") + "</td></tr>";

    });
    if (!items.length) h += "<tr><td colspan='10' class='empty'>No items in " + esc(partName(d, pid)) + " yet. Search above to add from CPWD DSR 2021, MPPWD SOR 2017, DSR Horticulture 2018 or your own SOR.</td></tr>";
    h += "</tbody><tfoot><tr><td colspan='6'>Total " + esc(partName(d, pid)) + "</td><td class='num'>" + inr(ts) + "</td><td></td><td class='num'>" + inr(ta) + "</td><td></td></tr></tfoot></table></div>";
    var oi = items.filter(function (x) { return S.est.open[x.id]; })[0];
    if (oi) { var inf2 = EP.itemInfo(oi); h += "<div class='panel mpanel' id='mpanel'><div class='row'><h3 class='grow'>Measurement · " + esc(partName(d, pid)) + " item " + EP.slOf(d, oi) + (inf2.code ? " · " + esc(inf2.code) : "") + "</h3><button class='btn ghost sm' data-open='" + oi.id + "'>Close</button></div><p class='muted' style='margin:0'>" + esc(inf2.desc) + "</p>" + measEditor(d, oi) + "</div>"; }
    return h;
  }
  function partName(d, id) { var p = d.parts.filter(function (x) { return x.id === id; })[0]; return p ? p.name : ""; }
  function measEditor(d, it) {
    var R = ro(), inf = EP.itemInfo(it), m = EP.measSum(d, it), kg = /^kg/i.test(inf.unit) || (it.meas || []).some(function (r) { return r.sec; });
    var h = '<div class="meas">';
    if (it.b === "x") {
      var x = it.x || {};
      h += '<div class="grid2"><label class="fld wide"><span class="lbl">Description</span><textarea class="in" rows="2" id="x-desc-' + it.id + '" data-x="' + it.id + '|desc"' + (R ? " disabled" : "") + ">" + esc(x.desc || "") + '</textarea></label><label class="fld"><span class="lbl">Unit</span><input class="in" id="x-unit-' + it.id + '" data-x="' + it.id + '|unit" value="' + esc(x.unit || "") + '"' + (R ? " disabled" : "") + '></label><label class="fld"><span class="lbl">Basis (printed as remark)</span><input class="in" id="x-src-' + it.id + '" data-x="' + it.id + '|src" value="' + esc(x.src || "") + '" placeholder="As per market quote"' + (R ? " disabled" : "") + '></label><label class="fld"><span class="lbl">Estimate rate ₹</span><input class="in n" id="x-sor-' + it.id + '" data-x="' + it.id + '|sor" value="' + esc(x.sor || "") + '"' + (R ? " disabled" : "") + '></label><label class="fld"><span class="lbl">Updated rate ₹ (blank = same)</span><input class="in n" id="x-an-' + it.id + '" data-x="' + it.id + '|an" value="' + esc(x.an || "") + '"' + (R ? " disabled" : "") + "></label></div>";
    }
    h += "<div class='mtw'><table class='t mt'><thead><tr><th>Type</th><th>Details</th>" + (kg ? "<th>Steel section (IS)</th>" : "") + "<th class='num'>No.</th><th class='num'>L (m)</th><th class='num'>B (m)</th><th class='num'>D / H (m)</th><th class='num'>Factor</th><th class='num'>Qty " + esc(inf.unit) + "</th><th></th></tr></thead><tbody>";
    (it.meas || []).forEach(function (r, ri) {
      var k = it.id + "|" + ri, id = "m-" + it.id + "-" + ri + "-", q = EP.rowQty(d, r);
      function inp(f, ph, cls) { return "<input class='in small " + (cls || "n") + "' id='" + id + f + "' data-mf='" + k + "|" + f + "' value='" + esc(r[f] == null ? "" : r[f]) + "' placeholder='" + (ph || "") + "' aria-label='" + f + "'" + (R ? " disabled" : "") + ">"; }
      h += "<tr class='k" + (r.k === "-" ? "m" : r.k === "h" ? "h" : r.k === "ref" ? "r" : "p") + "'><td><select class='in small' data-mk='" + k + "' aria-label='Row type'" + (R ? " disabled" : "") + ">" + TYPES.map(function (t) { return "<option value='" + t[0] + "'" + (r.k === t[0] ? " selected" : "") + ">" + t[1] + "</option>"; }).join("") + "</select></td>";
      if (r.k === "h") { h += "<td colspan='" + (kg ? 7 : 6) + "'>" + inp("d", "Heading, e.g. Deduction / Main building", "wide") + "</td><td></td>"; }
      else if (r.k === "ref") {
        var others = d.items.filter(function (x) { return x.id !== it.id; });
        h += "<td>" + inp("d", "Note (optional)", "wide") + "<select class='in small' style='margin-top:4px;max-width:100%' data-mref='" + k + "' aria-label='Take quantity from item'" + (R ? " disabled" : "") + "><option value=''>Take quantity from item…</option>" + others.map(function (o) { var oi = EP.itemInfo(o); return "<option value='" + o.id + "'" + (r.ref === o.id ? " selected" : "") + ">" + esc(partName(d, o.part) + " #" + EP.slOf(d, o) + " · " + (oi.code || "") + " · " + oi.desc.slice(0, 60) + " (" + U.qfmt(EP.itemQty(d, o)) + " " + oi.unit + ")") + "</option>"; }).join("") + "</select></td>" + (kg ? "<td></td>" : "") +
          "<td colspan='3'><select class='in small' data-mm='" + k + "' aria-label='How'" + (R ? " disabled" : "") + ">" + Object.keys(EP.REFMODE).map(function (m) { return "<option value='" + m + "'" + ((r.m || "x") === m ? " selected" : "") + ">" + EP.REFMODE[m] + "</option>"; }).join("") + "</select></td><td class='num'>" + inp("n", r.m === "pct" ? "e.g. 1" : r.m === "kgcum" ? "e.g. 50" : "1") + "</td><td></td>";
      } else {
        h += "<td>" + inp("d", r.k === "-" ? "e.g. Door D1" : "e.g. Main building", "wide") + "</td>";
        if (kg) h += "<td><select class='in small' data-msec='" + k + "' aria-label='Steel section'" + (R ? " disabled" : "") + "><option value=''>—</option>" + steelOptions(r.sec) + "</select></td>";
        h += "<td class='num'>" + inp("n") + "</td><td class='num'>" + inp("l") + "</td><td class='num'>" + inp("b") + "</td><td class='num'>" + inp("h") + "</td><td class='num'>" + inp("f", r.sec ? "" : "×") + "</td>";
      }
      h += "<td class='num'>" + (r.k === "h" ? "" : (r.k === "ref" ? "<span class='qv'>" + U.qfmt(q) + "</span>" : "<input class='in small n' id='" + id + "q' data-mf='" + k + "|q' value='" + esc(r.q == null ? "" : r.q) + "' placeholder='" + U.qfmt(q) + "' aria-label='Quantity (blank = calculated)'" + (R ? " disabled" : "") + ">")) + "</td><td>" + (R ? "" : "<button class='btn ghost sm' data-mdel='" + k + "' aria-label='Delete row'>✕</button>") + "</td></tr>";
    });
    if (!(it.meas || []).length) h += "<tr><td colspan='" + (kg ? 10 : 9) + "' class='muted'>No measurement rows. The quantity typed in the item row is used. Add rows to calculate No. × L × B × D × factor.</td></tr>";
    h += "</tbody></table></div>";
    if (!R) h += "<div class='row' style='gap:6px;flex-wrap:wrap'><button class='btn sec sm' data-madd='" + it.id + "|+'>+ Row</button><button class='btn sec sm' data-madd='" + it.id + "|-'>+ Deduction</button><button class='btn sec sm' data-madd='" + it.id + "|h'>+ Heading</button><button class='btn sec sm' data-madd='" + it.id + "|ref'>+ From another item (e.g. steel @ kg/cum of concrete)</button></div>";
    h += "<div class='msum'><span>Gross <strong>" + U.qfmt(m.plus) + "</strong></span><span>Deductions <strong>" + U.qfmt(m.minus) + "</strong></span><span>Net quantity <strong>" + U.qfmt(EP.itemQty(d, it)) + " " + esc(inf.unit) + "</strong></span></div>";
    var lib = it.b === "x" ? null : EP.anRate(it.b, it.c);
    h += "<div class='grid2'>" + (it.b !== "x" ? "<label class='fld'><span class='lbl'>Updated rate for this estimate only ₹</span><input class='in n' id='anr-" + it.id + "' data-anr='" + it.id + "' value='" + esc(it.anr || "") + "' placeholder='" + (lib != null ? "Library: " + inr(lib) : "") + "'" + (R ? " disabled" : "") + "></label>" : "") +
      "<label class='fld wide'><span class='lbl'>Remark (printed after the SOR reference)</span><input class='in' id='rem-" + it.id + "' data-rem='" + it.id + "' value='" + esc(it.rem || "") + "' placeholder='" + esc(inf.src) + "'" + (R ? " disabled" : "") + "></label>" +
      (d.parts.length > 1 && !R ? "<label class='fld'><span class='lbl'>Move to part</span><select class='in' data-mvpart='" + it.id + "'>" + d.parts.map(function (p) { return "<option value='" + esc(p.id) + "'" + (p.id === it.part ? " selected" : "") + ">" + esc(p.name) + "</option>"; }).join("") + "</select></label>" : "") + "</div>";
    return h + "</div>";
  }
  function steelOptions(sel) {
    var g = null, h = "";
    EP.STEEL.forEach(function (s) { if (s[3] !== g) { if (g) h += "</optgroup>"; g = s[3]; h += "<optgroup label='" + esc(g) + "'>"; } h += "<option value='" + esc(s[0]) + "'" + (s[0] === sel ? " selected" : "") + ">" + esc(s[0]) + " — " + s[1] + (/plate/i.test(s[0]) ? " kg/sqm" : " kg/m") + "</option>"; });
    return h + "</optgroup>";
  }
  function searchItems(q, lim) {
    q = q.trim().toLowerCase(); if (!q) return [];
    var words = q.split(/\s+/), out = [];
    Object.keys(EP.BOOKS).forEach(function (b) {
      EP.BOOKS[b].list.forEach(function (it) {
        var c = it.code.toLowerCase(), s = 0;
        if (c === q) s = 3; else if (c.indexOf(q) === 0) s = 2;
        else { var dd = it.desc.toLowerCase(); if (words.every(function (w) { return dd.indexOf(w) >= 0 || c.indexOf(w) >= 0; })) s = 1; }
        if (s) out.push({ b: b, it: it, s: s });
      });
    });
    out.sort(function (a, b) { return b.s - a.s; });
    return out.slice(0, lim || 30);
  }
  U.searchItems = searchItems;
  function addDropdown() {
    var q = S.est.addQ; if (!q) return "";
    var res = searchItems(q, 30);
    if (!res.length) return '<div class="dd"><div class="empty">No item matches “' + esc(q) + '”. Add it as a non-SOR item instead.</div></div>';
    return '<div class="dd">' + res.map(function (r) { return '<button type="button" data-add="' + r.b + "|" + esc(r.it.code) + '"><span><span class="sw ' + (r.b.indexOf("u:") === 0 ? "u" : r.b) + '"></span><strong>' + esc(r.it.code) + '</strong><br><span class="muted" style="font-size:11px">' + esc(EP.BOOKS[r.b].name) + '</span></span><span class="desc">' + esc(r.it.desc) + '</span><span class="num">₹' + inr(r.it.sor) + "/" + esc(r.it.unit) + "</span></button>"; }).join("") + "</div>";
  }

  /* ----- header, parts, GST ----- */
  function viewHeader(d) {
    var R = ro() ? " disabled" : "", hd = d.header;
    var h = '<div class="panel form"><h3>Header printed on every sheet</h3><div class="grid2">';
    [["org", "Organisation / company", "SOUTH EASTERN COALFIELDS LIMITED"], ["office", "Office", "OFFICE OF THE PROJECT ENGINEER (CIVIL)"], ["project", "Project / area", "GEVRA PROJECT"]].forEach(function (f) { h += '<label class="fld"><span class="lbl">' + f[1] + '</span><input class="in" id="hd-' + f[0] + '" data-hd="' + f[0] + '" value="' + esc(hd[f[0]] || "") + '" placeholder="' + esc(f[2]) + '"' + R + "></label>"; });
    h += '<label class="fld wide"><span class="lbl">Name of work</span><textarea class="in" rows="2" id="hd-work" data-hd="work" placeholder="Repair, renovation and beautification of …"' + R + ">" + esc(hd.work || "") + "</textarea></label></div>";
    h += '<h3>Signatures printed at the foot of each sheet</h3><div class="grid3">' + d.signs.map(function (s, i) { return '<div class="fld"><input class="in" id="sg-' + i + '-t" data-sg="' + i + '|title" value="' + esc(s.title) + '" placeholder="Designation" aria-label="Designation ' + (i + 1) + '"' + R + '><input class="in" id="sg-' + i + '-p" data-sg="' + i + '|place" value="' + esc(s.place) + '" placeholder="Place / office" aria-label="Place ' + (i + 1) + '"' + R + "></div>"; }).join("") + "</div>";
    h += '<h3>Rates & tax</h3><div class="grid2"><label class="fld"><span class="lbl">GST %</span><input class="in n" id="doc-gst" data-doc="gst" value="' + esc(d.gst) + '"' + R + '></label><label class="fld"><span class="lbl">Updated rate comes from</span><select class="in" data-doc="basis"' + R + '><option value="an"' + (d.basis !== "sor" ? " selected" : "") + '>Rate analysis with current basic rates (recommended)</option><option value="sor"' + (d.basis === "sor" ? " selected" : "") + ">SOR rate (unless an entered rate exists)</option></select></label></div>";
    h += '<h3>Parts</h3><p class="muted" style="margin:0">Each part gets its own measurement and abstract; the general abstract adds all parts.</p><div class="parts">' + d.parts.map(function (p) { var n = EP.partItems(d, p.id).length; return '<div class="row"><input class="in grow" id="pn-' + esc(p.id) + '" data-pname="' + esc(p.id) + '" value="' + esc(p.name) + '" aria-label="Part name"' + R + '><span class="muted">' + n + " items</span>" + (!R && d.parts.length > 1 ? '<button class="btn ghost sm" data-pdel="' + esc(p.id) + '">' + (n ? "Delete part & its items" : "Delete") + "</button>" : "") + "</div>"; }).join("") + "</div>" + (R ? "" : '<div class="row"><button type="button" class="btn sec sm" id="add-part">+ Add part</button><span class="grow"></span><button type="button" class="btn ghost" id="save-def">Use this header for my new estimates</button></div>');
    return h + "</div>";
  }

  /* ----- abstract preview ----- */
  function viewAbstract(d) {
    var T = EP.totals(d), g = +d.gst || 0, h = "";
    d.parts.forEach(function (p, pi) {
      var pt = T.parts[pi];
      h += '<div class="panel" style="padding:0;overflow:hidden"><div class="row" style="padding:10px 14px"><h3 class="grow">Abstract of cost — ' + esc(p.name) + '</h3></div><div class="tw" style="border:0;border-radius:0"><table class="t"><thead><tr><th class="num">Sl</th><th>Description</th><th>Unit</th><th class="num">Qty</th><th class="num">Estimate rate ₹</th><th class="num">Amount ₹</th><th class="num">Updated rate ₹</th><th class="num">Amount ₹</th><th>Remarks</th></tr></thead><tbody>';
      h += EP.partItems(d, p.id).map(function (it, i) { var inf = EP.itemInfo(it), r = EP.lineRates(d, it); return "<tr><td class='num'>" + (i + 1) + "</td><td><div class='desc'>" + esc(inf.desc) + "</div></td><td>" + esc(inf.unit) + "</td><td class='num'>" + U.qfmt(r.q) + "</td><td class='num'>" + inr(r.s) + "</td><td class='num'>" + inr(r.sa) + "</td><td class='num'>" + inr(r.a) + "</td><td class='num'>" + inr(r.aa) + "</td><td style='font-size:12px'>" + esc(inf.src + (it.rem ? " — " + it.rem : "")) + "</td></tr>"; }).join("") || "<tr><td colspan='9' class='empty'>No items.</td></tr>";
      h += "</tbody><tfoot><tr><td colspan='5'>Total</td><td class='num'>" + inr(pt.s) + "</td><td></td><td class='num'>" + inr(pt.a) + "</td><td></td></tr><tr><td colspan='5'>Add GST @ " + g + "%</td><td class='num'>" + inr(pt.s * g / 100) + "</td><td></td><td class='num'>" + inr(pt.a * g / 100) + "</td><td></td></tr><tr><td colspan='5'>Grand total</td><td class='num'>" + inr(pt.s * (1 + g / 100)) + "</td><td></td><td class='num'>" + inr(pt.a * (1 + g / 100)) + "</td><td></td></tr></tfoot></table></div></div>";
    });
    h += '<div class="panel" style="padding:0;overflow:hidden"><div style="padding:10px 14px"><h3>General abstract of cost</h3></div><div class="tw" style="border:0;border-radius:0"><table class="t"><thead><tr><th class="num">Sl</th><th>Description</th><th class="num">Estimate cost ₹</th><th class="num">Updated cost ₹</th></tr></thead><tbody>' + T.parts.map(function (p, i) { return "<tr><td class='num'>" + (i + 1) + "</td><td>" + esc(p.name) + "</td><td class='num'>" + inr(p.s) + "</td><td class='num'>" + inr(p.a) + "</td></tr>"; }).join("") + "</tbody><tfoot><tr><td colspan='2'>Total</td><td class='num'>" + inr(T.s) + "</td><td class='num'>" + inr(T.a) + "</td></tr><tr><td colspan='2'>Add GST @ " + g + "%</td><td class='num'>" + inr(T.sg) + "</td><td class='num'>" + inr(T.ag) + "</td></tr><tr><td colspan='2'>Grand total</td><td class='num'>" + inr(T.sT) + "</td><td class='num'>" + inr(T.aT) + "</td></tr><tr><td colspan='2'>Say (₹ lakh)</td><td class='num'>" + inr(T.sT / 1e5) + "</td><td class='num'>" + inr(T.aT / 1e5) + "</td></tr></tfoot></table></div></div>";
    return h;
  }

  /* ----- export ----- */
  var XL = [["all", "Full estimate", "All sheets in one workbook, linked by formulas: Measurement → Analysis → Abstract (every part, one after another) → General Abstract → BOQ."], ["meas", "Measurement", "Every item's No. × L × B × D × factor rows, deductions and totals with units, part by part."], ["an", "Analysis", "Rate analysis of each item with updated basic rates, add-ons and the rate adopted."], ["abs", "Abstract", "Abstract of cost for each part with SOR and updated rates and amounts, GST and grand total."], ["gen", "General abstract", "All parts added together, GST and grand total, both estimate and updated cost."], ["boq", "BOQ", "Bill of quantities for tender: description, unit and quantity, rate columns left blank."]];
  function viewExport(d) {
    var miss = [];
    if (!d.header.work) miss.push("name of work"); if (!d.header.org) miss.push("organisation");
    return '<div class="panel form">' + (miss.length ? '<div class="badge warn" style="white-space:normal;align-self:flex-start">Header is missing: ' + miss.join(", ") + '. Fill it in under “Header, parts & GST”.</div>' : "") + '<div class="xl-grid">' + XL.map(function (x) { return '<div class="xl"><h3>' + x[1] + '</h3><p class="muted">' + x[2] + '</p><button class="btn ' + (x[0] === "all" ? "pri" : "sec") + '" data-xl="' + x[0] + '">Download ' + x[1].toLowerCase() + " (.xlsx)</button></div>"; }).join("") + "</div></div>";
  }
  function fileName(which) { var n = (S.est.cur.name || "estimate").replace(/[^\w\- ]+/g, "").trim().slice(0, 60) || "estimate"; var lab = XL.filter(function (x) { return x[0] === which; })[0][1]; return n + (which === "all" ? "" : " - " + lab) + ".xlsx"; }

  /* ---------- events ---------- */
  document.addEventListener("input", function (e) {
    var t = e.target, d = doc();
    if (t.id === "add-q") { S.est.addQ = t.value; U.render(); return; }
    if (!d || ro()) return;
    var ds = t.dataset;
    if (t.id === "est-name") { S.est.cur.name = t.value; save(); return; }
    if (ds.iq) { change(function () { findItem(ds.iq).q = t.value; }); return; }
    if (ds.mf) { var p = ds.mf.split("|"), it = findItem(p[0]); change(function () { it.meas[+p[1]][p[2]] = t.value; }, p[2] !== "d"); return; }
    if (ds.x) { var q = ds.x.split("|"); change(function () { var it = findItem(q[0]); it.x = it.x || {}; it.x[q[1]] = t.value; }, q[1] === "sor" || q[1] === "an" || q[1] === "unit"); return; }
    if (ds.anr) { change(function () { findItem(ds.anr).anr = t.value; }); return; }
    if (ds.rem) { change(function () { findItem(ds.rem).rem = t.value; }, false); return; }
    if (ds.hd) { change(function () { d.header[ds.hd] = t.value; }, false); return; }
    if (ds.sg) { var s = ds.sg.split("|"); change(function () { d.signs[+s[0]][s[1]] = t.value; }, false); return; }
    if (ds.pname) { change(function () { d.parts.filter(function (p) { return p.id === ds.pname; })[0].name = t.value; }, false); return; }
    if (ds.doc === "gst") { change(function () { d.gst = U.num(t.value) || 0; }); return; }
  });
  document.addEventListener("change", function (e) {
    var t = e.target, ds = t.dataset, d = doc();
    if (t.id === "est-owner") { U.watchEst(t.value); return; }
    if (!d || ro()) return;
    if (ds.mk) { var p = ds.mk.split("|"); change(function () { var r = findItem(p[0]).meas[+p[1]]; r.k = t.value; }); }
    else if (ds.mref) { var a = ds.mref.split("|"); change(function () { findItem(a[0]).meas[+a[1]].ref = t.value; }); }
    else if (ds.mm) { var b = ds.mm.split("|"); change(function () { var r = findItem(b[0]).meas[+b[1]]; r.m = t.value; if (t.value === "kgcum" && !r.n) r.n = "50"; }); }
    else if (ds.msec) { var c = ds.msec.split("|"); change(function () { var r = findItem(c[0]).meas[+c[1]], st = EP.steel(t.value); r.sec = t.value || ""; if (st) r.f = String(st[1]); }); }
    else if (ds.mvpart) { change(function () { findItem(ds.mvpart).part = t.value; }); }
    else if (ds.doc === "basis") { change(function () { d.basis = t.value; }); }
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && S.est.addQ) { S.est.addQ = ""; U.render(); } });
  document.addEventListener("submit", function (e) {
    if (e.target.id !== "new-est") return; e.preventDefault();
    var n = document.getElementById("new-name").value.trim(); if (!n) return;
    newEstimate(n, EP.newDoc(defaults()));
  });
  document.addEventListener("click", function (e) {
    var t = e.target.closest("button"); if (!t || t.closest("nav.tabs")) return;
    var ds = t.dataset, d = doc();
    if (ds.est) { S.est.selId = ds.est; pick(); U.render(); return; }
    if (ds.sub) { S.est.sub = ds.sub; U.render(); return; }
    if (ds.part) { S.est.part = ds.part; S.est.addQ = ""; U.render(); return; }
    if (t.id === "mk-example") { example(); return; }
    if (ds.xl) { exportXl(ds.xl); return; }
    if (ds.open) { var was = !!S.est.open[ds.open]; S.est.open = {}; if (!was) S.est.open[ds.open] = true; U.render(); if (!was) setTimeout(function () { var p = document.getElementById("mpanel"); if (p) p.scrollIntoView({ behavior: "smooth", block: "start" }); }, 60); return; }
    if (!d || ro()) return;
    if (ds.add) { var p = ds.add.split("|"), b = p[0], c = p.slice(1).join("|"), id = EP.uid(); change(function () { d.items.push({ id: id, part: curPart(), b: b, c: c, q: "", rem: "", meas: [] }); }); S.est.addQ = ""; S.est.open = {}; S.est.open[id] = true; U.render(); return; }
    if (t.id === "add-x") { var xid = EP.uid(); change(function () { d.items.push({ id: xid, part: curPart(), b: "x", x: { desc: "", unit: "", sor: "", an: "", src: "As per market quote" }, q: "", rem: "", meas: [] }); }); S.est.open = {}; S.est.open[xid] = true; U.render(); setTimeout(function () { var n = document.getElementById("x-desc-" + xid); if (n) n.focus(); }, 60); return; }
    if (t.id === "add-part") { change(function () { var n = d.parts.length, id = EP.uid(); d.parts.push({ id: id, name: "Part " + String.fromCharCode(65 + n) }); S.est.part = id; }); return; }
    if (ds.pdel) { if (t.dataset.confirm !== "1") { t.dataset.confirm = "1"; t.textContent = "Click again to delete"; return; } change(function () { d.parts = d.parts.filter(function (p) { return p.id !== ds.pdel; }); d.items = d.items.filter(function (i) { return i.part !== ds.pdel; }); }); return; }
    if (ds.madd) { var m = ds.madd.split("|"); change(function () { var it = findItem(m[0]); it.meas = it.meas || []; it.meas.push({ k: m[1], d: "", n: m[1] === "ref" ? "" : "1" }); }); setTimeout(function () { var it = findItem(m[0]), ri = it.meas.length - 1, n = document.getElementById("m-" + it.id + "-" + ri + "-d"); if (n) n.focus(); }, 60); return; }
    if (ds.mdel) { var md = ds.mdel.split("|"); change(function () { findItem(md[0]).meas.splice(+md[1], 1); }); return; }
    if (ds.mv) { var mv = ds.mv.split("|"); change(function () { var it = findItem(mv[0]), list = EP.partItems(d, it.part), i = list.indexOf(it), j = i + (+mv[1]); if (j < 0 || j >= list.length) return; var a = d.items.indexOf(it), b2 = d.items.indexOf(list[j]); d.items[a] = list[j]; d.items[b2] = it; }); return; }
    if (ds.del) { if (t.dataset.confirm !== "1") { t.dataset.confirm = "1"; t.textContent = "Remove?"; return; } change(function () { d.items = d.items.filter(function (i) { return i.id !== ds.del; }); d.items.forEach(function (i) { (i.meas || []).forEach(function (r) { if (r.ref === ds.del) r.ref = ""; }); }); }); return; }
    if (t.id === "save-def") { saveDefaults(); return; }
    if (t.id === "del-est") {
      if (t.dataset.confirm !== "1") { t.dataset.confirm = "1"; t.textContent = "Click again to delete"; t.classList.add("sec"); return; }
      var did = S.est.cur.id;
      db().from("estimates").delete().eq("id", did).then(function (r) { if (U.fail(r, "Couldn't delete the estimate.")) return; U.toast("Estimate deleted"); S.est.list = S.est.list.filter(function (x) { return x.id !== did; }); if (S.est.owner === S.me.id) S.est.mine = S.est.list; S.est.selId = S.est.list[0] ? S.est.list[0].id : null; pick(); U.render(); });
    }
  });
  async function saveDefaults() {
    var d = doc(), def = { header: Object.assign({}, d.header, { work: "" }), signs: d.signs, gst: d.gst };
    var r = await db().from("profiles").update({ defaults: def }).eq("id", S.me.id);
    if (U.fail(r, "Couldn't save your default header.")) return; S.me.defaults = def; U.toast("New estimates will start with this header");
  }
  function exportXl(which) {
    var d = doc(); if (!d) return;
    try { EP.download(EP.buildWorkbook(d, which), fileName(which)); U.toast("Excel file downloaded"); }
    catch (err) { console.error(err); U.toast("Couldn't create the Excel file."); }
  }
  /* Example based on the weigh-bridge estimate (Part A: CPWD, Part B: MPPWD road) */
  function example() {
    var R = function (k, d, n, l, b, h, f) { return { k: k, d: d, n: n, l: l, b: b, h: h, f: f }; };
    var d = EP.newDoc(defaults());
    if (!d.header.org) d.header = { org: "SOUTH EASTERN COALFIELDS LIMITED", office: "OFFICE OF THE PROJECT ENGINEER (CIVIL)", project: "GEVRA PROJECT", work: "Repairing of control rooms of 15 weigh bridges and construction of approach road (example)" };
    else d.header.work = "Repairing of control rooms of weigh bridges and approach road (example)";
    d.parts = [{ id: "A", name: "Part A" }, { id: "B", name: "Part B" }];
    var sid = EP.uid(), cid = EP.uid();
    d.items = [
      { id: EP.uid(), part: "A", b: "cpwd", c: "14.87", meas: [R("+", "Roof type 1", "8", "5", "5"), R("+", "Roof type 2", "7", "5", "9")] },
      { id: EP.uid(), part: "A", b: "cpwd", c: "6.34.2", meas: [R("+", "Lumpsum repairs", "15", "2", "0.23", "1")] },
      { id: sid, part: "A", b: "cpwd", c: "10.1", meas: [{ k: "+", d: "Rafters", n: "96", l: "3.5", sec: "ISMB 100", f: "11.5" }, { k: "+", d: "Purlins", n: "8", l: "44", sec: "ISA 75x75x6", f: String(EP.steel("ISA 75x75x6")[1]) }] },
      { id: EP.uid(), part: "A", b: "cpwd", c: "13.88", meas: [R("+", "Main building walls", "1", "130", "3.1"), R("+", "Block A", "1", "40", "3.1"), R("h", "Deduction"), R("-", "Doors", "10", "0.9", "2.1"), R("-", "Windows", "18", "1.1", "1.1")] },
      { id: cid, part: "B", b: "mp", c: "13.6.B", meas: [R("+", "Road slab", "17", "20", "5", "0.3"), R("+", "Apron", "30", "10", "3", "0.15")] },
      { id: EP.uid(), part: "B", b: "mp", c: "3.3", meas: [R("+", "", "17", "20", "5", "0.7"), R("+", "Drain", "30", "20", "0.8", "0.3")] },
      { id: EP.uid(), part: "B", b: "mp", c: "4.1", meas: [R("+", "", "17", "20", "5", "0.3")] }
    ];
    if (EP.item("hort", "2.35")) d.items.push({ id: EP.uid(), part: "A", b: "hort", c: "2.35", q: "600", meas: [] });
    newEstimate("Weigh-bridge repairs & approach road (example)", d);
  }
  EP.exampleDoc = example;
})();
