/* Estimate Pro — rate books, rate engine, measurement maths, estimate model */
(function () {
  "use strict";
  var EP = window.EP = window.EP || {};
  var S = EP.S = { ovr: {}, userSors: [], basis: "an" };
  var BOOKS = EP.BOOKS = {}; // id -> {id,name,short,long,list,idx,ch,kind}
  var cp = null;

  /* ---------- helpers ---------- */
  EP.r2 = function (n) { return Math.round((n + Number.EPSILON) * 100) / 100; };
  EP.r3 = function (n) { return Math.round((n + Number.EPSILON) * 1000) / 1000; };
  EP.r05 = function (n) { return Math.round(Math.round(n / 0.05) * 0.05 * 100) / 100; };
  EP.enc = function (c) { return String(c).replace(/[^A-Za-z0-9_.\-]/g, function (ch) { return "~" + ch.charCodeAt(0).toString(16); }); };
  EP.uid = function () { return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3); };

  /* Safe arithmetic: numbers, + - * / x × ( ) and spaces. "15x45" → 675. Returns null when blank or invalid. */
  EP.ev = function (s) {
    if (s == null) return null; if (typeof s === "number") return isFinite(s) ? s : null;
    s = String(s).trim().replace(/,/g, "").replace(/[x×X]/g, "*"); if (!s) return null;
    var i = 0;
    function ws() { while (s[i] === " ") i++; }
    function num() { ws(); var m = /^\d*\.?\d+(e[+-]?\d+)?/i.exec(s.slice(i)); if (!m) throw 0; i += m[0].length; return parseFloat(m[0]); }
    function fac() { ws(); if (s[i] === "-") { i++; return -fac(); } if (s[i] === "+") { i++; return fac(); } if (s[i] === "(") { i++; var v = expr(); ws(); if (s[i] !== ")") throw 0; i++; return v; } return num(); }
    function term() { var v = fac(); for (;;) { ws(); if (s[i] === "*") { i++; v *= fac(); } else if (s[i] === "/") { i++; var d = fac(); if (!d) throw 0; v /= d; } else return v; } }
    function expr() { var v = term(); for (;;) { ws(); if (s[i] === "+") { i++; v += term(); } else if (s[i] === "-") { i++; v -= term(); } else return v; } }
    try { var v = expr(); ws(); return i === s.length && isFinite(v) ? v : null; } catch (e) { return null; }
  };

  /* ---------- books ---------- */
  function addBook(id, meta, list, ch) {
    var b = { id: id, name: meta.name, short: meta.short, long: meta.long, kind: meta.kind || "plain", list: list, idx: {}, ch: ch || {} };
    list.forEach(function (it) { b.idx[it.code] = it; });
    BOOKS[id] = b; return b;
  }
  EP.loadBuiltIn = function (cpwd, mppwd, hort) {
    cp = EP.cp = cpwd;
    var cl = cpwd.items.map(function (x) { return { code: x[0], desc: x[1], unit: x[2], sor: x[3], book: x[4], esta: x[5], src: x[6], ch: x[0].split(".")[0] }; });
    var cch = {}; cl.forEach(function (o) { cch[o.ch] = EP.CP_CH[o.ch] || "Chapter " + o.ch; });
    addBook("cpwd", { name: "CPWD DSR 2021", short: "SOR CPWD 2021", long: "CPWD Delhi Schedule of Rates 2021, Vol. 1 & 2 (updated Dec 2021)", kind: "cpwd" }, cl, cch);
    addBook("mp", { name: "MPPWD SOR 2017", short: "MPPWD SOR 2017", long: "MPPWD SOR 2017 — Roads & Bridges (w.e.f. 29.08.2017)" }, mppwd.items.map(function (x) { return { code: x[0], desc: x[1], unit: x[2], sor: x[3], ch: String(x[4]) }; }), mppwd.ch);
    addBook("hort", { name: "DSR Horticulture 2018", short: "DSOR Horticulture 2018", long: "CPWD DSR (Horticulture & Landscaping) 2018" }, hort.items.map(function (x) { return { code: x[0], desc: x[1], unit: x[2], sor: x[3], ch: x[4] }; }), hort.ch);
    EP.usage = {}; for (var k in cp.an) cp.an[k].L.forEach(function (l) { EP.usage[l[0]] = (EP.usage[l[0]] || 0) + 1; });
  };
  EP.loadUserSors = function (sors, items) {
    Object.keys(BOOKS).forEach(function (k) { if (k.indexOf("u:") === 0) delete BOOKS[k]; });
    S.userSors = sors;
    sors.forEach(function (s) {
      var its = items.filter(function (i) { return i.sor_id === s.id; }).map(function (i) { return { code: i.code, desc: i.descr, unit: i.unit || "", sor: i.rate != null ? +i.rate : null, an: i.an_rate != null ? +i.an_rate : null, anNote: i.an_note || "", ch: i.chapter || "" }; });
      var ch = {}; its.forEach(function (i) { if (i.ch) ch[i.ch] = i.ch; });
      addBook("u:" + s.id, { name: s.name, short: s.short || s.name, long: s.name + " (uploaded by you)", kind: "user" }, its, ch);
    });
  };
  EP.CP_CH = { 1: "Carriage of materials", 2: "Earth work", 3: "Mortars", 4: "Concrete work", 5: "Reinforced cement concrete", 6: "Brick work", 7: "Stone work", 8: "Marble & granite work", 9: "Wood & PVC work", 10: "Steel work", 11: "Flooring", 12: "Roofing", 13: "Finishing", 14: "Repairs to buildings", 15: "Dismantling & demolishing", 16: "Road work", 17: "Sanitary installations", 18: "Water supply", 19: "Drainage", 20: "Pile work", 21: "Aluminium work", 22: "Water proofing", 23: "Horticulture & landscape", 24: "Rain water harvesting", 25: "Conservation of heritage buildings", 26: "Miscellaneous" };

  /* ---------- rate engine ---------- */
  function basicBook(c) { var b = cp.basic[c]; return b ? (b[3] != null ? b[3] : b[2]) : null; }
  function basicOvr(c) { return S.ovr["cpwd:b:" + EP.enc(c)]; }
  function basicAn(c) { var o = basicOvr(c); return o && o.r != null ? o.r : basicBook(c); }
  EP.basicBook = basicBook; EP.basicOvr = basicOvr; EP.basicAn = basicAn;
  EP.itemOvr = function (b, c) { return S.ovr[b + ":i:" + EP.enc(c)]; };
  EP.item = function (b, c) { var bk = BOOKS[b]; return bk ? bk.idx[c] : null; };
  EP.sorRate = function (b, c) { var it = EP.item(b, c); return it ? it.sor : null; };
  EP.hasAn = function (b, c) { return b === "cpwd" && !!(cp && cp.an[c]); };
  function childFactor(c, depth) {
    var it = BOOKS.cpwd.idx[c], o = EP.itemOvr("cpwd", c);
    if (!it || !it.book) return 1;
    var r = anRateRaw("cpwd", c, depth + 1); return r && it.book ? r / it.book : 1;
  }
  /* Build-up of a CPWD analysis with current basic rates (+ optional line edits). Anchored on the book's own build-up (G). */
  EP.build = function (c, ov, depth) {
    var an = cp.an[c]; if (!an) return null; depth = depth || 0;
    var it = BOOKS.cpwd.idx[c]; var anchor = (it && it.book) || an.s; if (!anchor) return null;
    function calc(useOv) {
      var lines = an.L.map(function (l, i) {
        var lo = useOv && ov && ov.lines ? ov.lines[i] : null;
        var q = lo && lo.q != null ? lo.q : l[5], r = l[2];
        if (useOv) {
          if (lo && lo.r != null) r = lo.r;
          else if (cp.basic[l[0]] && basicOvr(l[0]) && basicBook(l[0])) r = l[2] * basicAn(l[0]) / basicBook(l[0]);
          else if (cp.an[l[0]] && l[0] !== c && depth < 3) r = l[2] * childFactor(l[0], depth);
        }
        var amt = (r != null && q != null) ? r * q / (l[3] || 1) : (l[6] || 0);
        return { code: l[0], desc: l[1], per: l[3], unit: l[4], sec: l[7], q: q, r: r, amt: amt };
      });
      return { lines: lines, sub: lines.reduce(function (a, x) { return a + x.amt; }, 0) };
    }
    var o0 = calc(false), o1 = calc(true);
    function addons(res, base, useOv) {
      var run = res.sub, out = [];
      an.A.forEach(function (a, j) {
        var pct = useOv && ov && ov.adds && ov.adds[j] != null ? ov.adds[j] : a[0];
        var add = a[2] ? a[3] * (base.sub ? res.sub / base.sub : 1) : run * pct / 100;
        run += add; out.push({ pct: pct, label: a[1], except: !!a[2], amt: add, run: run });
      });
      return { adds: out, total: run };
    }
    var a0 = addons(o0, o0, false), a1 = addons(o1, o0, true);
    var ratio = a0.total ? a1.total / a0.total : 1;
    return { rate: anchor * ratio, anchor: anchor, lines: o1.lines, adds: a1.adds, sub: o1.sub, total: a1.total, basis: an.b || 1, say: an.s };
  };
  /* Library-level analysis ("updated") rate. Default: CPWD analysis build-up with current basic rates; others: SOR. */
  function anRateRaw(b, c, depth) {
    var s = EP.sorRate(b, c), o = EP.itemOvr(b, c), it = EP.item(b, c);
    if (o && o.mode === "manual" && o.manual != null) return o.manual;
    if (o && o.mode === "sor") return s;
    if (b === "cpwd" && cp.an[c]) { var bu = EP.build(c, o && o.mode === "build" ? o : null, depth); return bu ? EP.r05(bu.rate) : s; }
    if (it && it.an != null) return it.an;
    return s;
  }
  var memo = {};
  EP.bump = function () { memo = {}; };
  EP.anRate = function (b, c) { var k = b + "|" + c; if (!(k in memo)) memo[k] = anRateRaw(b, c, 0); return memo[k]; };
  EP.modeLabel = function (b, c) {
    var o = EP.itemOvr(b, c), it = EP.item(b, c);
    if (o && o.mode === "manual") return "Entered rate";
    if (o && o.mode === "sor") return "SOR rate";
    if (o && o.mode === "build") return "Edited build-up";
    if (EP.hasAn(b, c)) return "Analysis";
    if (it && it.an != null) return "Entered rate";
    return "SOR rate";
  };

  /* ---------- estimate model ---------- */
  EP.newDoc = function (defaults) {
    var d = defaults || {};
    return { v: 2, header: Object.assign({ org: "", office: "", project: "", work: "" }, d.header || {}),
      signs: (d.signs && d.signs.length ? d.signs : [{ title: "Project Engineer (Civil)", place: "" }, { title: "AM / AE (Civil)", place: "" }, { title: "EA / OS (Civil)", place: "" }]).map(function (x) { return { title: x.title || "", place: x.place || "" }; }),
      gst: d.gst != null ? d.gst : 18, basis: "an", parts: [{ id: "A", name: "Part A" }], items: [] };
  };
  /* Convert an old flat estimate (lines) to the new document */
  EP.migrate = function (row) {
    if (row.data && row.data.v === 2) return row.data;
    var d = EP.newDoc(); d.gst = row.gst == null ? 18 : +row.gst;
    (row.lines || []).forEach(function (l) { d.items.push({ id: EP.uid(), part: "A", b: l.b, c: l.c, q: l.q != null ? String(l.q) : "", rem: l.rem || "", meas: [] }); });
    return d;
  };
  /* Steel unit weights. Bars: IS 1786 (d²/162.2). Beams/channels: IS 808:1989 tables. Angles, flats, squares, plates: from nominal size × 7850 kg/cum. */
  function r2(n) { return Math.round(n * 100) / 100; }
  var ST = [];
  [6, 8, 10, 12, 16, 20, 25, 28, 32, 36, 40].forEach(function (d) { ST.push(["TMT / round bar " + d + " mm", r2(d * d / 162.2), "IS 1786", "Bars (IS 1786)"]); });
  [[100, 11.5], [125, 13.0], [150, 14.9], [175, 19.3], [200, 25.4], [225, 31.2], [250, 37.3], [300, 46.0], [350, 52.4], [400, 61.6], [450, 72.4], [500, 86.9], [550, 103.7], [600, 122.6]].forEach(function (x) { ST.push(["ISMB " + x[0], x[1], "IS 808", "Beams ISMB (IS 808)"]); });
  [[75, 7.14], [100, 9.56], [125, 13.1], [150, 16.8], [175, 19.6], [200, 22.3], [225, 26.1], [250, 30.6], [300, 36.3], [350, 42.7], [400, 50.1]].forEach(function (x) { ST.push(["ISMC " + x[0], x[1], "IS 808", "Channels ISMC (IS 808)"]); });
  [[20, 3], [25, 3], [25, 5], [30, 3], [30, 5], [35, 5], [40, 5], [40, 6], [45, 5], [45, 6], [50, 5], [50, 6], [55, 6], [60, 6], [60, 8], [65, 6], [65, 8], [70, 6], [75, 6], [75, 8], [80, 8], [90, 8], [100, 8], [100, 10], [110, 10], [130, 10], [150, 12], [200, 16]].forEach(function (x) { ST.push(["ISA " + x[0] + "x" + x[0] + "x" + x[1], r2(x[1] * (2 * x[0] - x[1]) * 0.00785), "IS 808 size", "Equal angles ISA"]); });
  [[20, 3], [25, 3], [25, 5], [25, 6], [30, 5], [40, 5], [40, 6], [50, 5], [50, 6], [50, 8], [65, 8], [75, 8], [100, 10]].forEach(function (x) { ST.push(["Flat " + x[0] + "x" + x[1] + " mm", r2(x[0] * x[1] * 0.00785), "7850 kg/cum", "Flats"]); });
  [10, 12, 16, 20, 25].forEach(function (a) { ST.push(["Square bar " + a + " mm", r2(a * a * 0.00785), "7850 kg/cum", "Square bars"]); });
  [3, 4, 5, 6, 8, 10, 12, 16, 20, 25].forEach(function (t) { ST.push(["MS plate " + t + " mm (per sqm)", r2(t * 7.85), "7850 kg/cum", "Plates (kg per sqm)"]); });
  EP.STEEL = ST;
  EP.steel = function (name) { for (var i = 0; i < ST.length; i++) if (ST[i][0] === name) return ST[i]; return null; };
  EP.REFMODE = { x: "× factor", kgcum: "kg per cum", pct: "% by volume (×7850 kg/cum)" };
  EP.rowQty = function (doc, r, depth) {
    if (!r || r.k === "h") return null;
    if (r.k === "ref") {
      var t = doc.items.filter(function (i) { return i.id === r.ref; })[0]; if (!t || (depth || 0) > 5) return 0;
      var m = EP.ev(r.n), base = EP.itemQty(doc, t, (depth || 0) + 1);
      if (r.m === "pct") return base * (m == null ? 0 : m) / 100 * 7850;
      return base * (m == null ? 1 : m);
    }
    var mq = EP.ev(r.q); if (mq != null) return mq;
    var f = [r.n, r.l, r.b, r.h, r.f].map(EP.ev).filter(function (v) { return v != null; });
    if (!f.length) return 0;
    return f.reduce(function (a, v) { return a * v; }, 1);
  };
  EP.measSum = function (doc, it, depth) {
    var plus = 0, minus = 0, n = 0;
    (it.meas || []).forEach(function (r) { if (r.k === "h") return; n++; var q = EP.rowQty(doc, r, depth) || 0; if (r.k === "-") minus += q; else plus += q; });
    return { plus: plus, minus: minus, net: plus - minus, n: n };
  };
  EP.itemQty = function (doc, it, depth) {
    var m = EP.measSum(doc, it, depth);
    if (m.n) return EP.r3(m.net);
    var v = EP.ev(it.q); return v == null ? 0 : v;
  };
  EP.itemInfo = function (it) {
    if (it.b === "x") { var x = it.x || {}; return { desc: x.desc || "(describe the item)", unit: x.unit || "", src: x.src || "Non-SOR item", code: "" }; }
    var bk = BOOKS[it.b], i = bk && bk.idx[it.c];
    return { desc: i ? i.desc : "(item " + it.c + " not found in " + (bk ? bk.name : "this SOR") + ")", unit: i ? i.unit : "", src: (bk ? bk.short : it.b) + " " + it.c, code: it.c, missing: !i };
  };
  /* Rates used in an estimate line: s = SOR (estimate) rate, a = updated rate */
  EP.lineRates = function (doc, it) {
    var s, a, how;
    if (it.b === "x") { var x = it.x || {}; s = EP.ev(x.sor); a = EP.ev(x.an); if (a == null) a = s; how = x.src || "Non-SOR"; }
    else {
      s = EP.sorRate(it.b, it.c);
      var o = EP.itemOvr(it.b, it.c), lib = EP.anRate(it.b, it.c);
      if (doc.basis === "sor" && !(o && (o.mode === "manual" || o.mode === "build"))) { a = s; how = "SOR rate"; }
      else { a = lib; how = EP.modeLabel(it.b, it.c); }
    }
    var ov = EP.ev(it.anr); if (ov != null) { a = ov; how = "Entered for this estimate"; }
    var q = EP.itemQty(doc, it);
    return { s: s, a: a, q: q, sa: s != null ? EP.r2(s * q) : 0, aa: a != null ? EP.r2(a * q) : 0, how: how };
  };
  EP.partItems = function (doc, pid) { return doc.items.filter(function (i) { return i.part === pid; }); };
  EP.totals = function (doc) {
    var parts = doc.parts.map(function (p) {
      var s = 0, a = 0; EP.partItems(doc, p.id).forEach(function (it) { var r = EP.lineRates(doc, it); s += r.sa; a += r.aa; });
      return { id: p.id, name: p.name, s: EP.r2(s), a: EP.r2(a) };
    });
    var s = parts.reduce(function (x, p) { return x + p.s; }, 0), a = parts.reduce(function (x, p) { return x + p.a; }, 0), g = (+doc.gst || 0) / 100;
    return { parts: parts, s: EP.r2(s), a: EP.r2(a), sg: EP.r2(s * g), ag: EP.r2(a * g), sT: EP.r2(s * (1 + g)), aT: EP.r2(a * (1 + g)) };
  };
  EP.slOf = function (doc, it) { return EP.partItems(doc, it.part).indexOf(it) + 1; };
})();
