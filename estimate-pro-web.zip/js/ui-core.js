/* Estimate Pro — UI core: state, helpers, auth (email + Google, one active session), navigation, users */
(function () {
  "use strict";
  var EP = window.EP, S = EP.S;
  Object.assign(S, {
    tab: "estimates", me: { id: null, name: "", email: "", role: "user", isOwner: false, canEdit: false, defaults: null }, names: {},
    auth: { mode: "in", busy: false, msg: "", err: "" },
    lib: { book: "cpwd", q: "", ch: "", edited: false, sel: null, draft: null },
    basic: { kind: "L", q: "" },
    est: { owner: null, list: [], mine: [], selId: null, cur: null, users: [], usersInfo: [], sub: "items", part: null, open: {}, addQ: "" },
    sor: { step: 0 }, loaded: false
  });
  var U = EP.ui = {};
  var db = null, rt = null, sessTimer = null;
  U.db = function () { return db; };
  var $ = U.$ = function (s) { return document.querySelector(s); };
  U.esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  U.inr = function (n, d) { if (n == null || isNaN(n)) return "—"; d = d == null ? 2 : d; var neg = n < 0; n = Math.abs(n); var p = n.toFixed(d).split("."); var x = p[0], l3 = x.slice(-3), rest = x.slice(0, -3); if (rest) l3 = "," + l3; rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ","); return (neg ? "−" : "") + rest + l3 + (d ? "." + p[1] : ""); };
  U.qfmt = function (n) { if (n == null || isNaN(n)) return "—"; return (+n.toFixed(3)).toLocaleString("en-IN", { maximumFractionDigits: 3 }); };
  U.num = function (v) { var x = parseFloat(String(v).replace(/,/g, "")); return isNaN(x) ? null : x; };
  U.when = function (t) { if (!t) return ""; return new Date(t).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }); };
  U.toast = function (m) { var t = $("#toast"); t.textContent = m; t.hidden = false; clearTimeout(U.toast._t); U.toast._t = setTimeout(function () { t.hidden = true; }, 2800); };
  U.fail = function (r, msg) { if (r && r.error) { console.error(r.error); if (/row-level security|permission|JWT|session/i.test(r.error.message || "")) checkSession(); U.toast(msg || r.error.message); return true; } return false; };
  U.nameOf = function (id) { return (S.names[id] && S.names[id].name) || (id === S.me.id ? (S.me.name || "you") : "Someone"); };
  U.resolveNames = async function (ids) {
    if (!db || !S.me.id) return; ids = ids.filter(function (i, n) { return i && !S.names[i] && ids.indexOf(i) === n; }); if (!ids.length) return;
    ids.forEach(function (i) { S.names[i] = { name: "" }; });
    var r = await db.rpc("profile_names", { ids: ids }); if (!r.error && r.data) { r.data.forEach(function (p) { S.names[p.id] = { name: p.full_name }; }); U.render(); }
  };

  /* ---------- render ---------- */
  var rq = 0, views = U.views = {};
  U.render = function () { if (rq) return; rq = requestAnimationFrame(function () { rq = 0; doRender(); }); };
  function doRender() {
    document.querySelectorAll("nav.tabs button").forEach(function (b) { if (b.dataset.tab === S.tab) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current"); });
    $("#tab-users").hidden = !S.me.isOwner; $("nav.tabs").hidden = !S.me.id;
    renderWho();
    var v = $("#view"), ae = document.activeElement, aid = ae && ae.id, sel = null;
    try { sel = ae && ae.selectionStart; } catch (e) {}
    if (!db) { v.innerHTML = viewNoConfig(); return; }
    if (!S.me.id || S.auth.mode === "newpw") { v.innerHTML = viewAuth(); restore(aid, sel); return; }
    if (!S.loaded) { v.innerHTML = '<div class="empty">Loading rate books: CPWD DSR 2021 (Vol. 1 & 2), MPPWD SOR 2017, DSR Horticulture 2018…</div>'; return; }
    var fn = views[S.tab] || views.estimates; if (S.tab === "users" && !S.me.isOwner) fn = views.estimates;
    var sy = window.scrollY;
    v.innerHTML = fn();
    restore(aid, sel); if (window.scrollY !== sy) window.scrollTo(0, sy);
    if (U.after) U.after();
  }
  function restore(aid, sel) { if (!aid) return; var n = document.getElementById(aid); if (!n) return; n.focus({ preventScroll: true }); try { if (sel != null && n.setSelectionRange) n.setSelectionRange(sel, sel); } catch (e) {} }
  function renderWho() {
    var m = S.me, w = $("#who");
    if (!m.id) { w.innerHTML = ""; return; }
    var role = m.isOwner ? '<span class="role sa">Super admin</span>' : (m.canEdit ? '<span class="role">Editor</span>' : '<span class="role">User</span>');
    var nm = m.name || m.email || "You", ini = nm.split(/[\s@.]+/).filter(Boolean).map(function (x) { return x[0]; }).join("").slice(0, 2).toUpperCase();
    w.innerHTML = '<span class="av" aria-hidden="true">' + U.esc(ini) + '</span><span class="who-name">' + U.esc(nm) + "</span>" + role + '<button type="button" class="btn ghost sm" id="sign-out">Sign out</button>';
  }
  U.setTab = function (t) { S.tab = t; try { history.replaceState(null, "", "#" + t); } catch (e) {} U.render(); window.scrollTo(0, 0); };

  /* ---------- sign-in ---------- */
  function viewNoConfig() { return '<div class="panel auth"><h1>Connect Supabase</h1><p class="muted">Open <code>config.js</code> and paste your Supabase project URL and anon (public) key, then reload. Both are in Supabase → Project Settings → API.</p></div>'; }
  var G_ICON = '<svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
  function viewAuth() {
    var A = S.auth, m = A.mode;
    var title = { "in": "Sign in", up: "Create your account", reset: "Reset password", newpw: "Set a new password" }[m];
    var h = '<form class="panel auth" id="auth-form" novalidate><img class="auth-logo" src="logo.png" alt=""><h1>' + title + "</h1>";
    if (m === "in") h += '<p class="muted">Estimates on CPWD DSR 2021, MPPWD SOR 2017, DSR Horticulture 2018 and your own SORs.</p>';
    if (m === "in" || m === "up") h += '<button type="button" class="btn sec google" id="google">' + G_ICON + "<span>Continue with Google</span></button><div class=\"or\"><span>or with email</span></div>";
    if (m === "up") h += '<label class="fld"><span class="lbl">Full name</span><input class="in" id="au-name" autocomplete="name" required></label>';
    if (m !== "newpw") h += '<label class="fld"><span class="lbl">Email</span><input class="in" id="au-email" type="email" autocomplete="email" required></label>';
    if (m !== "reset") h += '<label class="fld"><span class="lbl">' + (m === "newpw" ? "New password" : "Password") + '</span><input class="in" id="au-pass" type="password" minlength="8" autocomplete="' + (m === "in" ? "current-password" : "new-password") + '" required></label>';
    if (m === "up" || m === "newpw") h += '<span class="muted" style="font-size:12px;margin-top:-6px">At least 8 characters.</span>';
    if (A.err) h += '<div class="badge dan" role="alert" style="white-space:normal">' + U.esc(A.err) + "</div>";
    if (A.msg) h += '<div class="badge info" role="status" style="white-space:normal">' + U.esc(A.msg) + "</div>";
    h += '<button class="btn pri" type="submit"' + (A.busy ? " disabled" : "") + ">" + (A.busy ? "Please wait…" : { "in": "Sign in", up: "Create account", reset: "Send reset link", newpw: "Save password" }[m]) + "</button>";
    if (m === "in") h += '<div class="row" style="justify-content:space-between"><button type="button" class="btn ghost sm" data-auth="reset">Forgot password?</button><button type="button" class="btn ghost sm" data-auth="up">Create an account</button></div>';
    else if (m !== "newpw") h += '<button type="button" class="btn ghost sm" data-auth="in">Back to sign in</button>';
    h += '<p class="muted" style="font-size:12px;margin:0">One device at a time: signing in here signs you out on any other computer.</p>';
    return h + "</form>";
  }
  function flagClaim() { try { localStorage.setItem("ep_claim", "1"); } catch (e) {} }
  async function submitAuth() {
    var A = S.auth; if (A.busy) return;
    var v = function (id) { var n = document.getElementById(id); return n ? n.value.trim() : ""; };
    var email = v("au-email"), pn = document.getElementById("au-pass"), pass = pn ? pn.value : "", name = v("au-name");
    A.err = ""; A.msg = "";
    if (A.mode !== "newpw" && !/^\S+@\S+\.\S+$/.test(email)) { A.err = "Enter a valid email address."; U.render(); return; }
    if ((A.mode === "up" || A.mode === "newpw") && pass.length < 8) { A.err = "Use at least 8 characters for the password."; U.render(); return; }
    if (A.mode === "up" && !name) { A.err = "Enter your full name."; U.render(); return; }
    A.busy = true; U.render();
    var back = location.origin + location.pathname, r;
    if (A.mode === "in") { flagClaim(); r = await db.auth.signInWithPassword({ email: email, password: pass }); }
    else if (A.mode === "up") { flagClaim(); r = await db.auth.signUp({ email: email, password: pass, options: { data: { full_name: name }, emailRedirectTo: back } }); }
    else if (A.mode === "reset") r = await db.auth.resetPasswordForEmail(email, { redirectTo: back });
    else r = await db.auth.updateUser({ password: pass });
    A.busy = false;
    if (r.error) { A.err = r.error.message === "Invalid login credentials" ? "Wrong email or password." : r.error.message; U.render(); return; }
    if (A.mode === "up" && !(r.data && r.data.session)) { A.mode = "in"; A.msg = "Account created. Check your email and click the confirmation link, then sign in."; }
    else if (A.mode === "reset") A.msg = "If that email has an account, a reset link is on its way.";
    else if (A.mode === "newpw") { A.mode = "in"; U.toast("Password updated"); }
    U.render();
  }
  async function google() {
    flagClaim();
    var r = await db.auth.signInWithOAuth({ provider: "google", options: { redirectTo: location.origin + location.pathname } });
    if (r.error) { S.auth.err = /provider is not enabled/i.test(r.error.message) ? "Google sign-in isn't switched on yet. The admin enables it in Supabase → Authentication → Providers → Google." : r.error.message; U.render(); }
  }

  /* ---------- one active session per user ---------- */
  async function claimOrCheck() {
    var want = false; try { want = localStorage.getItem("ep_claim") === "1"; } catch (e) {}
    var st = await db.rpc("session_status");
    var status = st.data || "none";
    if (want || status === "none") {
      var c = await db.rpc("claim_session", { device: navigator.userAgent.slice(0, 180) });
      try { localStorage.removeItem("ep_claim"); } catch (e) {}
      if (c.error) { console.error(c.error); return true; }
      db.auth.signOut({ scope: "others" }).catch(function () {});
      return true;
    }
    if (status === "replaced") { await kicked(); return false; }
    return true;
  }
  async function checkSession() {
    if (!db || !S.me.id) return;
    var st = await db.rpc("session_status"); if (st.error) return;
    if (st.data === "replaced") kicked();
  }
  async function kicked() {
    clearInterval(sessTimer);
    await db.auth.signOut({ scope: "local" });
    S.auth.mode = "in"; S.auth.err = ""; S.auth.msg = "You were signed out because your account signed in on another computer. Sign in again to continue here (that will sign out the other computer).";
    U.render();
  }

  async function loadMe(session) {
    var u = session && session.user;
    if (!u) { S.me = { id: null, name: "", email: "", role: "user", isOwner: false, canEdit: false }; S.ovr = {}; EP.bump(); S.est = { owner: null, list: [], mine: [], selId: null, cur: null, users: [], usersInfo: [], sub: "items", part: null, open: {}, addQ: "" }; if (rt) { db.removeChannel(rt); rt = null; } clearInterval(sessTimer); U.render(); return; }
    if (S.me.id === u.id) return;
    var ok = await claimOrCheck(); if (!ok) return;
    var r = await db.from("profiles").select("id,email,full_name,role,defaults").eq("id", u.id).maybeSingle();
    var p = r.data || { full_name: (u.user_metadata && (u.user_metadata.full_name || u.user_metadata.name)) || "", role: "user", email: u.email };
    S.me = { id: u.id, name: p.full_name, email: p.email || u.email, role: p.role, isOwner: p.role === "super_admin", canEdit: p.role === "super_admin" || p.role === "editor", defaults: p.defaults || null };
    S.names[u.id] = { name: p.full_name };
    if (S.auth.mode !== "newpw") { S.auth.msg = ""; S.auth.err = ""; }
    db.rpc("touch_last_seen").then(function () {});
    clearInterval(sessTimer); sessTimer = setInterval(checkSession, 30000);
    loadOvr(); U.loadSors(); U.watchEst(S.me.id);
    U.render();
  }
  function ovrRow(row) { var o = Object.assign({}, row.data || {}); o.by = row.updated_by; o.at = row.updated_at ? Date.parse(row.updated_at) : null; return o; }
  async function loadOvr() {
    var all = [], from = 0;
    while (true) { var r = await db.from("rate_overrides").select("id,data,updated_by,updated_at").range(from, from + 999); if (r.error) break; all = all.concat(r.data); if (r.data.length < 1000) break; from += 1000; }
    var o = {}, ids = []; all.forEach(function (row) { o[row.id] = ovrRow(row); if (row.updated_by) ids.push(row.updated_by); });
    S.ovr = o; EP.bump(); U.resolveNames(ids); U.render();
    if (!rt) rt = db.channel("rate-overrides").on("postgres_changes", { event: "*", schema: "public", table: "rate_overrides" }, function (p) {
      if (p.eventType === "DELETE") { if (p.old && p.old.id) delete S.ovr[p.old.id]; }
      else if (p.new && p.new.id) { S.ovr[p.new.id] = ovrRow(p.new); U.resolveNames([p.new.updated_by]); }
      EP.bump(); U.render();
    }).subscribe();
  }
  U.ovrSet = async function (id, body) { var d = Object.assign({}, body); delete d.by; delete d.at; var r = await db.from("rate_overrides").upsert({ id: id, data: d, updated_by: S.me.id }); if (U.fail(r, "Couldn't save. Only editors can change library rates.")) return false; S.ovr[id] = Object.assign({}, d, { by: S.me.id, at: Date.now() }); EP.bump(); U.render(); return true; };
  U.ovrDel = async function (id) { var r = await db.from("rate_overrides").delete().eq("id", id); if (U.fail(r, "Couldn't reset. Only editors can change library rates.")) return false; delete S.ovr[id]; EP.bump(); U.render(); return true; };

  /* ---------- users (super admin) ---------- */
  U.loadUsers = async function () {
    var r = await db.rpc("admin_users"); if (r.error) return;
    S.est.usersInfo = r.data; S.est.users = r.data.map(function (u) { return u.id; });
    r.data.forEach(function (u) { S.names[u.id] = { name: u.full_name || u.email }; }); U.render();
  };
  views.users = function () {
    var h = '<div style="display:flex;flex-direction:column;gap:12px;max-width:1080px"><h1>Users & projects</h1><p class="muted" style="margin:0">Anyone with the app link can sign up with Google or email. Everyone starts as a <strong>User</strong> with private projects and private uploaded SORs. <strong>Editors</strong> can also change library analysis rates and basic rates. You are the super admin and can open anyone\'s projects. Each person can be signed in on one computer at a time.</p>';
    h += '<div class="tw"><table class="t"><thead><tr><th>Person</th><th>Email</th><th>Role</th><th class="num">Estimates</th><th>Joined</th><th>Last active</th><th>Signed in on</th><th></th></tr></thead><tbody>';
    var roles = [["user", "User"], ["editor", "Editor"], ["super_admin", "Super admin"]];
    h += S.est.usersInfo.length ? S.est.usersInfo.map(function (u) {
      var me = u.id === S.me.id;
      var rc = me ? "<span class='role sa'>Super admin</span>" : "<select class='in' data-role='" + U.esc(u.id) + "' aria-label='Role for " + U.esc(u.full_name || u.email) + "'>" + roles.map(function (r) { return "<option value='" + r[0] + "'" + (u.role === r[0] ? " selected" : "") + ">" + r[1] + "</option>"; }).join("") + "</select>";
      var dev = u.device ? U.esc(/Windows/.test(u.device) ? "Windows" : /Mac/.test(u.device) ? "Mac" : /Android/.test(u.device) ? "Android" : /iPhone|iPad/.test(u.device) ? "iPhone / iPad" : /Linux/.test(u.device) ? "Linux" : "Browser") + " · " + U.when(u.session_at) : "—";
      return "<tr><td>" + U.esc((u.full_name || "—") + (me ? " (you)" : "")) + "</td><td>" + U.esc(u.email || "") + "</td><td>" + rc + "</td><td class='num'>" + u.estimates + "</td><td>" + U.when(u.created_at) + "</td><td>" + U.when(u.last_seen) + "</td><td>" + dev + "</td><td><button class='btn ghost sm' data-openuser='" + U.esc(u.id) + "'>Open projects</button></td></tr>";
    }).join("") : "<tr><td colspan='8' class='empty'>Nobody else has signed up yet.</td></tr>";
    return h + "</tbody></table></div></div>";
  };
  async function setRole(id, role) { var r = await db.from("profiles").update({ role: role }).eq("id", id); if (U.fail(r, "Couldn't change the role.")) { U.loadUsers(); return; } U.toast("Role updated"); U.loadUsers(); }

  /* ---------- global events ---------- */
  document.addEventListener("click", function (e) {
    var t = e.target.closest("button"); if (!t) return;
    if (t.closest("nav.tabs")) { U.setTab(t.dataset.tab); return; }
    if (t.dataset.auth) { S.auth.mode = t.dataset.auth; S.auth.err = ""; S.auth.msg = ""; U.render(); }
    else if (t.id === "google") google();
    else if (t.id === "sign-out") { db.rpc("release_session").then(function () { db.auth.signOut(); }); }
    else if (t.dataset.openuser) { U.setTab("estimates"); U.watchEst(t.dataset.openuser); }
  });
  document.addEventListener("submit", function (e) { if (e.target.id === "auth-form") { e.preventDefault(); submitAuth(); } });
  document.addEventListener("change", function (e) { var t = e.target; if (t.dataset.role && S.me.isOwner) setRole(t.dataset.role, t.value); });
  window.addEventListener("focus", function () { checkSession(); });

  /* ---------- boot ---------- */
  U.boot = async function () {
    var h = (location.hash || "").slice(1); if (["estimates", "library", "basic", "sors", "users"].indexOf(h) >= 0) S.tab = h;
    var cfg = window.EP_CONFIG || {};
    if (window.supabase && cfg.url && cfg.anonKey && cfg.url.indexOf("YOUR-") < 0) db = window.supabase.createClient(cfg.url, cfg.anonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
    U.render();
    Promise.all(["cpwd.json", "mppwd.json", "hort.json"].map(function (f) { return fetch(f).then(function (r) { if (!r.ok) throw new Error(f); return r.json(); }); }))
      .then(function (a) { EP.loadBuiltIn(a[0], a[1], a[2]); S.loaded = true; U.render(); })
      .catch(function () { $("#view").innerHTML = '<div class="panel empty">The rate books didn\'t load. Reload the page.</div>'; });
    if (!db) return;
    db.auth.onAuthStateChange(function (ev, session) {
      if (ev === "PASSWORD_RECOVERY") { S.auth.mode = "newpw"; S.auth.err = ""; S.auth.msg = ""; }
      if (ev === "TOKEN_REFRESHED") return;
      setTimeout(function () { loadMe(session); }, 0);
    });
  };
})();
